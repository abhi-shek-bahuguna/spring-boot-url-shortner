import logo from './logo.svg';
import './App.css';
import UrlForm from './components/Form';
function App() {
  return (
    <div style={{ display: "flex", justifyContent: "center", marginTop: "50px" }}>
    <UrlForm />
  </div>
  );
}

export default App;
